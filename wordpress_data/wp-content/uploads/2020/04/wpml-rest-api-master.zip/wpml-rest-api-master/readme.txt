=== WPML REST API ===
Contributors: shooper
Donate link: http://shawnhooper.ca/
Tags: wpml, api, rest
Requires at least: 4.7
Tested up to: 4.7.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds links to posts in other languages into the results of a WP REST API query for sites running the WPML plugin.

== Description ==

Adds links to posts in other languages into the results of a WP REST API query for sites running the WPML plugin.

== Screenshots ==

1. This screenshot shows an excerpt of the JSON returned by the WP REST API when a page has translations available

== Changelog ==

= 1.0 =
* First release.
