---
name: 🤝 SUPPORT QUESTION
about: If you have a support question! 💬

---

-----------^ Click "Preview" for a nicer view!

This is a FOSS (Free & Open Source Software) project. Providing support is a full-time job and so it's not provided for free. No promises there. 😇

If you'd like to support this project or hire [Ahmad Awais](https://twitter.com/mrahmadawais/) (maker of `create-guten-block`) then feel free to contact here → https://AhmadAwais.com/contact/.


---

If you'd like us to keep producing professional free and open source software (FOSS). Consider paying for an hour of our dev-time. We'll spend two hours on open source for each contribution. Yeah, that's right, you pay for one hour and get both of us (Awais & Maedah) to spend an hour as a thank you.

🚀 $99.99 — [Support for one hour or more →](https://pay.paddle.com/checkout/515568)
🔰 $49.99 — [Support half an hour maintenance →](https://pay.paddle.com/checkout/527253)
☕️ $9.99 — [Buy us lunch or coffee to keep us trucking #OpenSource →](https://pay.paddle.com/checkout/527254)