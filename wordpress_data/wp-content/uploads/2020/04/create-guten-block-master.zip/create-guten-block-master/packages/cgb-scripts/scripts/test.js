// @remove-file-on-eject

const chalk = require( 'chalk' );

console.clear();
console.log( '\n👌 ', chalk.dim( ' Support Awais via VSCode Power User at' ), 'https://VSCode.pro' );
